package com.example.agentic

import org.junit.jupiter.api.Test
import org.springframework.boot.test.context.SpringBootTest

@SpringBootTest
class AgenticBackendApplicationTests {

	@Test
	fun contextLoads() {
	}

}
