package com.example.agentic

import org.springframework.boot.autoconfigure.SpringBootApplication
import org.springframework.boot.runApplication

@SpringBootApplication
class AgenticBackendApplication

fun main(args: Array<String>) {
	runApplication<AgenticBackendApplication>(*args)
}
